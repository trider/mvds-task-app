const { ApolloServer, gql } = require('apollo-server-lambda');
const {
  ApolloServerPluginLandingPageLocalDefault
} = require('apollo-server-core');

// Construct a schema, using GraphQL schema language
const typeDefs = gql`

  scalar JSON

  type Query {
     # app
     appQuery(api:String, command:String, payload:JSON): JSON
    
    # Users
    getUsers(payload:JSON): JSON
    getUser(payload:JSON): JSON
    
    # Tasks
    getTasks(payload:JSON): JSON
    getTask(payload:JSON): JSON

    type Mutation {
    # app
    # appLogin(payload:JSON): JSON
    appRun(api:String, command:String, payload:JSON): JSON


    # Users
    login(payload:JSON): JSON
    createUser(payload:JSON): JSON
    updateUser(payload:JSON): JSON
    deleteUser(payload:JSON): JSON
    unDeleteUser(payload:JSON): JSON

    # Tasks
    createTask(payload:JSON): JSON
    updateTask(payload:JSON): JSON
    deleteTask(payload:JSON): JSON
    deleteAllTasks(payload:JSON): JSON
    unDeleteAllTasks(payload:JSON): JSON
    unDeleteTask(payload:JSON): JSON
  
  }

  }



`;

// Provide resolver functions for your schema fields
const resolvers = {
  Query: {
    hello: () => 'Hello world!',
    // App
    appQuery: async (parent, args, { dataSources }, context) => {
      console.log(args)
      if (args.api === 'tasks') {
        return tasks.Query[args.command](parent, args, { dataSources }, context)
      }
      else if (args.api === 'users') {
        return users.Query[args.command](parent, args, { dataSources }, context)
      }

    },
    // Users
    getUsers: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.getItemsData(
          { db: 'tasksDB', collection: 'users', query: {} }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        return data

      })
      return getData.then(data => data).catch((err) => console.log(err))
    },
    getUser: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.getItemData(
          { db: 'tasksDB', collection: 'users', query: { "userName": args.payload.userName } }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        return data

      })
      return getData.then(data => data).catch((err) => console.log(err))
    },
    // Tasks

  },
  Mutation: {
    // App
    appRun: async (parent, args, { dataSources }, context) => {
      console.log(args)
      if (args.api === 'tasks') {
        return tasks.Mutation[args.command](parent, args, { dataSources }, context)
      }
      else if (args.api === 'users') {
        return users.Mutation[args.command](parent, args, { dataSources }, context)
      }
    },
    // Users
    login: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.getItemData(
          { db: 'tasksDB', collection: 'users', query: { "email": args.payload.email, "password": args.payload.password } }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        if(data !== null) {
          return {
            ...data,
            status: "User found",
            isAuthenticated: true
          }
  
        }
        else{
          return {
            status: "User not found",
            isAuthenticated: false
          }
        }
  
      })
      return getData.then(data => data).catch((err) => console.log(err))
    },
    createUser: async (parent, args, { dataSources }, context) => {
        let users = null
        let userId = null
        const getData = new Promise((resolve) => {
          dataSources.mongoAPI.getItemsData(
            { db: 'tasksDB', collection: 'users', query: {} }
          ).then((data, err) => resolve(data))
  
        }).then((data) => {
          users = data
          userId = users.length + 1
          return dataSources.mongoAPI.writeItemData({
            db: 'tasksDB',
            collection: 'users',
            data: {
              ...args.payload,
              userId: userId,
              created: new Date(),
              updated: new Date(),
              isActive: true
  
            }
          })
        }).then((data) => {
          return dataSources.mongoAPI.getItemData(
            { db: 'tasksDB', collection: 'users', query: { "userId": userId } }
          )
        })
        return getData.then(data => data).catch((err) => {
          console.log(err)
        })
    },
    updateUser: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.updateItemData(
          {
            db: 'tasksDB',
            collection: 'users',
            query: { "_id": ObjectID(args.payload.id) },
            data: args.payload.data
          }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        console.log(data.result)
        return dataSources.mongoAPI.getItemData(
          { db: 'tasksDB', collection: 'users', query: { "_id": ObjectID(args.payload.id) } }
        )
      })
      return getData.then(data => data).catch((err) => {
        console.log(err)
      })
    },
    deleteUser: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.updateItemData(
          {
            db: 'tasksDB',
            collection: 'users',
            query: { "_id": ObjectID(args.payload.id) },
            data: {
              isActive: false,
              updated: new Date()
            }
          }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        console.log(data.result)
        return dataSources.mongoAPI.getItemData(
          { db: 'tasksDB', collection: 'users', query: { "_id": ObjectID(args.payload.id) } }
        )
      })
      return getData.then(data => data).catch((err) => {
        console.log(err)
      })
    },
    unDeleteUser: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.updateItemData(
          {
            db: 'tasksDB',
            collection: 'users',
            query: { "_id": ObjectID(args.payload.id) },
            data: {
              isActive: true,
              updated: new Date()
            }
          }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        console.log(data.result)
        return dataSources.mongoAPI.getItemData(
          { db: 'tasksDB', collection: 'users', query: { "_id": ObjectID(args.payload.id) } }
        )
      })
      return getData.then(data => data).catch((err) => {
        console.log(err)
      })
    },



  },
};

const server = new ApolloServer({
  typeDefs,
  resolvers,
  csrfPrevention: true,
  cache: 'bounded',
  context: ({ event, context, express }) => ({
    headers: event.headers,
    functionName: context.functionName,
    event,
    context,
    expressRequest: express.req,
  }),
  plugins: [
    ApolloServerPluginLandingPageLocalDefault({ embed: true }),
  ],
});

exports.graphqlHandler = server.createHandler();