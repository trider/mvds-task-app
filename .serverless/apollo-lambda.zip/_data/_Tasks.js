const userTasks= [
 {
   id: "6630ab326e723ac1ea6dce7a",
   description: "My first task",
   name: "A task",
   taskId: 1,
   user: "jonnygold",
   added: "2024-05-01T22:00:00.000Z",
   updated: "2024-05-01T14:16:01.119Z",
   status: "do",
   isActive: true,
   isEdit: false
 },
 {
   id: "6630fe5d6e723ac1ea6dce7e",
   description: "My second task",
   name: "Another task",
   taskId: 2,
   user: "jonnygold",
   added: "2024-05-01T22:00:00.000Z",
   updated:"2024-05-01T14:16:01.119Z",
   status: "doing",
   isActive: true,
   isEdit: false
 },
 {
   id: "6630fe826e723ac1ea6dce7f",
   description: "My task",
   name: "task",
   taskId: 3,
   user: "jonnygold",
   added: "2024-05-01T22:00:00.000Z",
   updated:"2024-05-01T14:16:01.119Z",
   status: "done",
   isActive: true,
   isEdit: false
 },
 {
   id: "6631f17cc4c9b7f5ab3c28c3",
   name: "Yet another task",
   description: "My fourth task",
   user: "jonnygold",
   taskId: 4,
   added: "2024-05-01T22:00:00.000Z",
   updated:"2024-05-01T14:16:01.119Z",
   isActive: true,
   status: "do",
   isEdit: false

 },
 {
   id: "66323f0d54b80929f84ebdd2",
   user: "jonnygold",
   name: "New Task",
   description: "My new task description",
   status: "do",
   taskId: 5,
   added: "2024-05-01T22:00:00.000Z",
   updated:"2024-05-01T14:16:01.119Z",
   isActive: true,
   isEdit: false
 }

]

export default userTasks