const { ApolloServer, gql } = require('apollo-server-lambda');
const {
  ApolloServerPluginLandingPageLocalDefault
} = require('apollo-server-core');

// Construct a schema, using GraphQL schema language
const typeDefs = gql`

  scalar JSON

  type Query {
     # app
     appQuery(api:String, command:String, payload:JSON): JSON
    
    # Users
    getUsers(payload:JSON): JSON
    getUser(payload:JSON): JSON
    
    # Tasks
    getTasks(payload:JSON): JSON
    getTask(payload:JSON): JSON

    type Mutation {
    # app
    # appLogin(payload:JSON): JSON
    appRun(api:String, command:String, payload:JSON): JSON


    # Users
    login(payload:JSON): JSON
    createUser(payload:JSON): JSON
    updateUser(payload:JSON): JSON
    deleteUser(payload:JSON): JSON
    unDeleteUser(payload:JSON): JSON

    # Tasks
    createTask(payload:JSON): JSON
    updateTask(payload:JSON): JSON
    deleteTask(payload:JSON): JSON
    deleteAllTasks(payload:JSON): JSON
    unDeleteAllTasks(payload:JSON): JSON
    unDeleteTask(payload:JSON): JSON
  
  }

  }



`;

// Provide resolver functions for your schema fields
const resolvers = {
  Query: {
    hello: () => 'Hello world!',
  },
};

const server = new ApolloServer({
  typeDefs,
  resolvers,
  csrfPrevention: true,
  cache: 'bounded',
  context: ({ event, context, express }) => ({
    headers: event.headers,
    functionName: context.functionName,
    event,
    context,
    expressRequest: express.req,
  }),
  plugins: [
    ApolloServerPluginLandingPageLocalDefault({ embed: true }),
  ],
});

exports.graphqlHandler = server.createHandler();