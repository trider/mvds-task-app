const tableCols = [
 'name',
 'description',
 'added',
 'updated',
 'status',
];

export default tableCols