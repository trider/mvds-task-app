// InState
const users	=  require('./users/users')

module.exports = {
	Query: {
		...users.Query,
	}

};