
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'trider',
  applicationName: 'graphql-task-app',
  appUid: 'HDljqlWk9gfwrD4wx4',
  orgUid: 'da2982e0-f0ee-4744-9efc-d4f7b0a1b324',
  deploymentUid: '24284ab4-a077-45b2-9e88-009f82cc87d7',
  serviceName: 'apollo-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./graphql.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}