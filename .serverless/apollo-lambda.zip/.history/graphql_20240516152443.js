// graphql.js

const { ApolloServer, gql } = require('apollo-server-lambda');
const {
  ApolloServerPluginLandingPageLocalDefault
} = require('apollo-server-core');
const dataSources = require('./datasources');
// const GraphQLJSON = require('graphql-type-json');

// Construct a schema, using GraphQL schema language
const typeDefs = gql`

  scalar JSON
  type Query {
    # Users
    getUsers(payload:JSON): JSON
    getUser(payload:JSON): JSON

    # Tasks
    getTasks(payload:JSON): JSON
    getTask(payload:JSON): JSON
  
  }
  type Mutation {
  
    # Users
    login(payload:JSON): JSON
    createUser(payload:JSON): JSON
    updateUser(payload:JSON): JSON
    deleteUser(payload:JSON): JSON
    unDeleteUser(payload:JSON): JSON

    # Tasks
    createTask(payload:JSON): JSON
    updateTask(payload:JSON): JSON
    deleteTask(payload:JSON): JSON
    deleteAllTasks(payload:JSON): JSON
    unDeleteAllTasks(payload:JSON): JSON
    unDeleteTask(payload:JSON): JSON
  
  }
`;

// Provide resolver functions for your schema fields
const resolvers = {
  Query: {
    getUsers: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.getItemsData(
          { db: 'tasksDB', collection: 'users', query: {  } }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        return data

      })
      return getData.then(data => data).catch((err) => console.log(err))
    },
    getUser: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.getItemData(
          { db: 'tasksDB', collection: 'users', query: { "userName": args.payload.userName } }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        return data

      })
      return getData.then(data => data).catch((err) => console.log(err))
    },
    getTasks: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.getItemsData(
          { db: 'tasksDB', collection: 'tasks', query: { user: args.payload.user, isActive:true } }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        return data

      })
      return getData.then(data => data).catch((err) => console.log(err))
    },
    getTask: async (parent, args, { dataSources }, context) => {
      const getData = new Promise((resolve) => {
        dataSources.mongoAPI.getItemData(
          { db: 'tasksDB', collection: 'tasks', query: { taskId:1} }
        ).then((data, err) => resolve(data))
      }).then((data) => {
        return data

      })
      return getData.then(data => data).catch((err) => console.log(err))
    },
  },
  
};

const server = new ApolloServer({
  typeDefs,
  resolvers,
  dataSources:dataSources,
  csrfPrevention: true,
  cache: 'bounded',
  context: ({ event, context, express }) => ({
    headers: event.headers,
    functionName: context.functionName,
    event,
    context,
    expressRequest: express.req,
  }),
  plugins: [
    ApolloServerPluginLandingPageLocalDefault({ embed: true }),
  ],
});

exports.graphqlHandler = server.createHandler();