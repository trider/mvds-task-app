const Users = [
 {
   id: "6630a7516e723ac1ea6dce75",
   email: "jonnygold@gmail.com",
   name: "Jonathan Gold",
   password: "1234",
   userName: "jonnygold",
   isActive: true,
   userId: 1,
   created: "2024-05-01T08:57:20.123Z",
   updated: "2024-05-01T08:57:20.123Z"

 },
 {
   id: "663203f0062b854f9356c434",
   email: "jongold@gmail.com",
   name: "Jon Gold",
   password: "1234",
   userName: "jongold",
   userId: 2,
   created: "2024-05-01T09:08:55.211Z",
   updated: "2024-05-01T09:08:55.211Z",
   isActive: true
 }
];

export default Users